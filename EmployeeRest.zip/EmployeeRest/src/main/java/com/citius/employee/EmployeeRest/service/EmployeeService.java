package com.citius.employee.EmployeeRest.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.citius.employee.EmployeeRest.model.Employee;

@Component
public class EmployeeService {
	private static Map<String,Employee> emplRepo=new HashMap<>();
	static {
		Employee e1=new Employee();
		e1.setEmployeeId("10");
		e1.setEmployeeName("Ayush");
		emplRepo.put(e1.getEmployeeId(), e1);
		Employee e2=new Employee();
		
		e2.setEmployeeId("20");
		e2.setEmployeeName("Sarthak");
		emplRepo.put(e2.getEmployeeId(), e2);
	}
	
	public Map<String,Employee> getEmployeeList(){
		return emplRepo;
		
	}
	
	public List<Employee> getEmployeeId(String id){
		List emp=new ArrayList<Employee>();
		Employee e=new Employee();
		if(emplRepo.containsKey(id)) {
		e.setEmployeeId(emplRepo.get(id).getEmployeeId());
		e.setEmployeeName(emplRepo.get(id).getEmployeeName());
		}else {
			e.setEmployeeId(null);
			e.setEmployeeName(null);
		}
		emp.add(e);
		return emp;
		
	}

	public Map<String,Employee> addNewEmployee(Employee employee) {
		// TODO Auto-generated method stub
		emplRepo.put(employee.getEmployeeId(), employee);
		return emplRepo;
	}

	public Map<String,Employee> addNewEmployeePut(Employee employee) {
		// TODO Auto-generated method stub

		if(emplRepo.containsKey(employee.getEmployeeId())) {
			emplRepo.remove(employee.getEmployeeId());
			emplRepo.put(employee.getEmployeeId(), employee);
		}else {
		emplRepo.put(employee.getEmployeeId(), employee);
		}
		return emplRepo;
	}

	public String deleteEmployee(String id) {
		// TODO Auto-generated method stub
		String msg=null;
		if(emplRepo.containsKey(id)) {
		emplRepo.remove(id);
		msg="Removed the employee with id: "+id;
		}else {
			msg="Employee not found";	
		}
		return msg;
	}

}

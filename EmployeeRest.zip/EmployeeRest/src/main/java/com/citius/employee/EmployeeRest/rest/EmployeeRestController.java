package com.citius.employee.EmployeeRest.rest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citius.employee.EmployeeRest.model.Employee;
import com.citius.employee.EmployeeRest.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeRestController {

	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/employee")
	public Map<String,Employee> findAll(){
		
		return employeeService.getEmployeeList();
	}
	@GetMapping("/employee/{id}")
	public List<Employee> findId(@PathVariable("id") String id){
		
		return employeeService.getEmployeeId(id);
	}
	
	
	//add a new employee
	@PostMapping("/employee/post/{id}")
	public Map<String,Employee> addEmployeePost(@RequestBody Employee employee) {
		//employee.setEmployeeId("0");
		
		return employeeService.addNewEmployee(employee);	
	}
	
	@PutMapping("/employee/put")
	public Map<String,Employee> addEmployee(@RequestBody Employee employee) {
		return employeeService.addNewEmployeePut(employee);
	}
	
	@DeleteMapping("/employee/delete/{id}")
	public String deleteEmployee(@PathVariable("id") String id){
		return employeeService.deleteEmployee(id);
	}
}
